package com.examly.springapp.service;

import com.examly.springapp.model.DriverRequest;
import com.examly.springapp.model.Payment;
import com.examly.springapp.repository.DriverRequestRepo;
import com.examly.springapp.repository.PaymentRepo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.json.JSONObject;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepo paymentRepo;
    private final DriverRequestRepo driverRequestRepo;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    public PaymentServiceImpl(
            PaymentRepo paymentRepo,
            DriverRequestRepo driverRequestRepo) {

        this.paymentRepo = paymentRepo;
        this.driverRequestRepo = driverRequestRepo;
    }

    @Override
    public Object createOrder(Long driverRequestId, String customerEmail) {

        // 1. Find the driver's request
        DriverRequest request = driverRequestRepo
                .findById(driverRequestId)
                .orElseThrow(() ->
                        new RuntimeException("Driver request not found"));

        // 2. Verify that this request belongs to the logged-in customer
        if (request.getUser() == null ||
                !request.getUser().getEmail().equalsIgnoreCase(customerEmail)) {

            throw new RuntimeException("You are not allowed to pay for this request");
        }

        // 3. Get the payment amount from the database
        Double amount = request.getPaymentAmount();

        if (amount == null || amount <= 0) {
            throw new RuntimeException("Invalid payment amount");
        }

        // 4. Convert rupees to paise
        long amountInPaise = Math.round(amount * 100);

        try {

            // 5. Create Razorpay order request
            JSONObject orderRequest = new JSONObject();

            orderRequest.put("amount", amountInPaise);
            orderRequest.put("currency", "INR");
            orderRequest.put(
                    "receipt",
                    "driver_request_" + driverRequestId
            );

            // 6. Create Basic Authentication
            String credentials =
                    razorpayKeyId + ":" + razorpayKeySecret;

            String encodedCredentials =
                    Base64.getEncoder()
                            .encodeToString(
                                    credentials.getBytes(StandardCharsets.UTF_8)
                            );

            // 7. Send request to Razorpay
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(
                            "https://api.razorpay.com/v1/orders"))
                    .header(
                            "Authorization",
                            "Basic " + encodedCredentials)
                    .header(
                            "Content-Type",
                            "application/json")
                    .POST(
                            HttpRequest.BodyPublishers.ofString(
                                    orderRequest.toString()))
                    .build();

            HttpClient client = HttpClient.newHttpClient();

            HttpResponse<String> response =
                    client.send(
                            httpRequest,
                            HttpResponse.BodyHandlers.ofString()
                    );

            // 8. Check Razorpay response
            if (response.statusCode() < 200 ||
                    response.statusCode() >= 300) {

                throw new RuntimeException(
                        "Razorpay order creation failed: "
                                + response.body());
            }

            // 9. Read Razorpay response
            JSONObject razorpayResponse =
                    new JSONObject(response.body());

            String razorpayOrderId =
                    razorpayResponse.getString("id");

            // 10. Save payment in our database
            Payment payment = new Payment();

            payment.setDriverRequest(request);
            payment.setUser(request.getUser());
            payment.setAmount(amount);
            payment.setCurrency("INR");
            payment.setRazorpayOrderId(razorpayOrderId);
            payment.setStatus("CREATED");

            paymentRepo.save(payment);

            // 11. Return required information to Angular
            JSONObject result = new JSONObject();

            result.put("orderId", razorpayOrderId);
            result.put("amount", amountInPaise);
            result.put("currency", "INR");
            result.put("keyId", razorpayKeyId);
            result.put("driverRequestId", driverRequestId);

            return result.toMap();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Unable to create Razorpay order: "
                            + e.getMessage());
        }
    }

    @Override
    public Object verifyPayment(
            String razorpayOrderId,
            String razorpayPaymentId,
            String razorpaySignature,
            String customerEmail) {
    
        try {
    
            // 1. Find the payment using Razorpay Order ID
            Payment payment = paymentRepo
                    .findByRazorpayOrderId(razorpayOrderId)
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "Payment order not found"));
    
            // 2. Check that this payment belongs to the logged-in customer
            if (payment.getUser() == null ||
                    !payment.getUser()
                            .getEmail()
                            .equalsIgnoreCase(customerEmail)) {
    
                throw new RuntimeException(
                        "You are not allowed to verify this payment");
            }
    
            // 3. Create the string that Razorpay expects
            String data =
                    razorpayOrderId + "|" + razorpayPaymentId;
    
            // 4. Create HMAC-SHA256 signature
            javax.crypto.Mac mac =
                    javax.crypto.Mac.getInstance("HmacSHA256");
    
            javax.crypto.spec.SecretKeySpec secretKey =
                    new javax.crypto.spec.SecretKeySpec(
                            razorpayKeySecret.getBytes(
                                    java.nio.charset.StandardCharsets.UTF_8),
                            "HmacSHA256");
    
            mac.init(secretKey);
    
            byte[] generatedSignature =
                    mac.doFinal(
                            data.getBytes(
                                    java.nio.charset.StandardCharsets.UTF_8));
    
            // 5. Convert generated signature to hexadecimal
            StringBuilder generatedHex =
                    new StringBuilder();
    
            for (byte b : generatedSignature) {
    
                generatedHex.append(
                        String.format("%02x", b));
            }
    
            String expectedSignature =
                    generatedHex.toString();
    
            // 6. Compare Razorpay signature with our signature
            boolean signatureValid =
                    java.security.MessageDigest.isEqual(
                            expectedSignature.getBytes(
                                    java.nio.charset.StandardCharsets.UTF_8),
                            razorpaySignature.getBytes(
                                    java.nio.charset.StandardCharsets.UTF_8));
    
            if (!signatureValid) {
    
                payment.setStatus("FAILED");
    
                paymentRepo.save(payment);
    
                throw new RuntimeException(
                        "Invalid Razorpay payment signature");
            }
    
            // 7. Store successful payment details
            payment.setRazorpayPaymentId(
                    razorpayPaymentId);
    
            payment.setRazorpaySignature(
                    razorpaySignature);
    
            payment.setStatus("SUCCESS");
    
            payment.setPaymentDate(
                    java.time.LocalDateTime.now());
    
            paymentRepo.save(payment);
    
            // 8. Close the driver's request
            DriverRequest request =
                    payment.getDriverRequest();
    
            request.setStatus("Closed");
    
            driverRequestRepo.save(request);
    
            // 9. Return success response
            java.util.Map<String, Object> result =
                    new java.util.HashMap<>();
    
            result.put("success", true);
    
            result.put(
                    "message",
                    "Payment verified successfully");
    
            result.put(
                    "paymentId",
                    payment.getPaymentId());
    
            result.put(
                    "razorpayPaymentId",
                    razorpayPaymentId);
    
            result.put(
                    "amount",
                    payment.getAmount());
    
            result.put(
                    "status",
                    payment.getStatus());
    
            return result;
    
        } catch (Exception e) {
    
            throw new RuntimeException(
                    "Payment verification failed: "
                            + e.getMessage());
        }
    }
}
