package com.examly.springapp.controller;

import com.examly.springapp.service.PaymentService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // =========================
    // CREATE RAZORPAY ORDER
    // =========================

    @PostMapping("/create-order/{driverRequestId}")
    public ResponseEntity<?> createOrder(
            @PathVariable Long driverRequestId,
            Authentication authentication) {

        String customerEmail =
                authentication.getName();

        return ResponseEntity.ok(
                paymentService.createOrder(
                        driverRequestId,
                        customerEmail
                )
        );
    }


    // =========================
    // VERIFY RAZORPAY PAYMENT
    // =========================

    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(
            @RequestBody Map<String, String> paymentData,
            Authentication authentication) {

        String customerEmail =
                authentication.getName();

        String razorpayOrderId =
                paymentData.get("razorpay_order_id");

        String razorpayPaymentId =
                paymentData.get("razorpay_payment_id");

        String razorpaySignature =
                paymentData.get("razorpay_signature");

        return ResponseEntity.ok(
                paymentService.verifyPayment(
                        razorpayOrderId,
                        razorpayPaymentId,
                        razorpaySignature,
                        customerEmail
                )
        );
    }
}