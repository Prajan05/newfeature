package com.examly.springapp.service;

public interface PaymentService {

    Object createOrder(Long driverRequestId, String customerEmail);

    Object verifyPayment(
            String razorpayOrderId,
            String razorpayPaymentId,
            String razorpaySignature,
            String customerEmail);
}
