export const environment = {
    production: false,
    // Replace "localhost" with the URL of your workspace port 8080 if needed.
    apiUrl: 'https://8080-fbefbcdfbfbbeaeeaedeefaffffdbceabeddeaed.premiumproject.examly.io'
  };