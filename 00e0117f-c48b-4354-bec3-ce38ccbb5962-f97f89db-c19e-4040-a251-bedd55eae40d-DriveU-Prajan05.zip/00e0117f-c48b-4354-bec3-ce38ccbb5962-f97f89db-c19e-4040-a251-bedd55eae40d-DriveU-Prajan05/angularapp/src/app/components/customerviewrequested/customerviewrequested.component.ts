import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DriverRequestService } from '../../services/driver-request.service';
import { PaymentService } from '../../services/payment.service';
import { AuthService } from '../../services/auth.service';

import { DriverRequest } from '../../models/driver-request.model';

import {
  combineDateTime,
  formatDuration,
  parseDurationToMinutes,
  toDateString,
  toDisplayDate,
  toTimeString
} from 'src/utils/format';

import {
  getDriverImage,
  useDefaultAvatar
} from 'src/utils/driver-image';

declare var Razorpay: any;

@Component({
  selector: 'app-customerviewrequested',
  templateUrl: './customerviewrequested.component.html',
  styleUrls: ['./customerviewrequested.component.css']
})
export class CustomerviewrequestedComponent
  implements OnInit, OnDestroy {

  requests: DriverRequest[] = [];

  searchText: string = '';

  selectedRequest: DriverRequest | null = null;

  showDetailsModal: boolean = false;
  showDeleteModal: boolean = false;
  showPayModal: boolean = false;

  payLoading: boolean = false;

  private payTimer: any;

  toDateString = toDateString;
  toTimeString = toTimeString;
  toDisplayDate = toDisplayDate;

  getDriverImage = getDriverImage;
  useDefaultAvatar = useDefaultAvatar;

  constructor(
    private driverRequestService: DriverRequestService,
    private paymentService: PaymentService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadRequests();
  }

  ngOnDestroy(): void {
    clearTimeout(this.payTimer);
  }

  // =========================================================
  // LOAD CUSTOMER REQUESTS
  // =========================================================

  loadRequests(): void {

    const userId = this.authService.getUserId();

    if (userId === null) {
      return;
    }

    this.driverRequestService
      .getDriverRequestsByUserId(userId)
      .subscribe({

        next: (requests) => {
          this.requests = requests || [];
        },

        error: (error) => {

          console.error(
            'Failed to load requests:',
            error
          );

          this.requests = [];
        }

      });
  }

  // =========================================================
  // SEARCH
  // =========================================================

  get filteredRequests(): DriverRequest[] {

    const query =
      this.searchText.trim().toLowerCase();

    if (!query) {
      return this.requests;
    }

    return this.requests.filter(
      (request) =>
        (request.driver?.driverName || '')
          .toLowerCase()
          .includes(query)
    );
  }

  // =========================================================
  // STATUS CHECKS
  // =========================================================

  isPending(
    request: DriverRequest
  ): boolean {

    return request.status === 'Pending';
  }

  canEndTrip(
    request: DriverRequest
  ): boolean {

    return request.status === 'Approved';
  }

  canFetchPayAmount(
    request: DriverRequest
  ): boolean {

    return (
      request.status === 'Trip End'
      ||
      request.status === 'Closed'
    );
  }

  // =========================================================
  // SHOW DETAILS
  // =========================================================

  showMore(
    request: DriverRequest
  ): void {

    this.selectedRequest = request;

    this.showDetailsModal = true;
  }

  // =========================================================
  // CLOSE DETAILS
  // =========================================================

  closeDetails(): void {

    this.showDetailsModal = false;

    this.selectedRequest = null;
  }

  // =========================================================
  // EDIT REQUEST
  // =========================================================

  editRequest(
    request: DriverRequest
  ): void {

    if (this.isPending(request)) {

      this.router.navigate([
        '/customer-request/edit',
        request.driverRequestId
      ]);

    }
  }

  // =========================================================
  // DELETE REQUEST
  // =========================================================

  askDelete(
    request: DriverRequest
  ): void {

    if (this.isPending(request)) {

      this.selectedRequest = request;

      this.showDeleteModal = true;
    }
  }

  // =========================================================
  // CANCEL DELETE
  // =========================================================

  cancelDelete(): void {

    this.showDeleteModal = false;

    this.selectedRequest = null;
  }

  // =========================================================
  // CONFIRM DELETE
  // =========================================================

  confirmDelete(): void {

    const id =
      this.selectedRequest?.driverRequestId;

    if (id === undefined) {
      return;
    }

    this.driverRequestService
      .deleteDriverRequest(id)
      .subscribe({

        next: () => {

          this.requests =
            this.requests.filter(
              (request) =>
                request.driverRequestId !== id
            );

          this.cancelDelete();
        },

        error: (error) => {

          console.error(
            'Failed to delete request:',
            error
          );

          this.cancelDelete();
        }

      });
  }

  // =========================================================
  // END TRIP
  // =========================================================

  endTrip(
    request: DriverRequest
  ): void {

    if (
      !this.canEndTrip(request) ||
      request.driverRequestId === undefined
    ) {

      return;
    }

    const now = new Date();

    const start =
      combineDateTime(
        request.tripDate,
        request.timeSlot
      );

    let minutes = start
      ? Math.round(
        (
          now.getTime() -
          start.getTime()
        ) / 60000
      )
      : 0;

    /*
     * If the calculated duration is zero
     * or negative, use the estimated duration.
     */
    if (minutes <= 0) {

      minutes =
        parseDurationToMinutes(
          request.estimatedDuration
        );
    }

    const hourlyRate =
      Number(
        request.driver?.hourlyRate || 0
      );

    const paymentAmount =
      Math.round(
        hourlyRate *
        (minutes / 60) *
        100
      ) / 100;

    const update = {

      status: 'Trip End',

      actualDropDate:
        toDateString(now),

      actualDropTime:
        toTimeString(
          now,
          true
        ),

      actualDuration:
        formatDuration(minutes),

      paymentAmount

    };

    this.driverRequestService
      .updateDriverRequest(
        request.driverRequestId,
        update as unknown as DriverRequest
      )
      .subscribe({

        next: () => {

          request.status =
            update.status;

          request.actualDropDate =
            update.actualDropDate as unknown as Date;

          request.actualDropTime =
            update.actualDropTime as unknown as Date;

          request.actualDuration =
            update.actualDuration;

          request.paymentAmount =
            update.paymentAmount;

        },

        error: (error) => {

          console.error(
            'Failed to end trip:',
            error
          );

          alert(
            'Unable to end the trip.'
          );
        }

      });
  }

  // =========================================================
  // SHOW PAYMENT MODAL
  // =========================================================

  fetchPayAmount(
    request: DriverRequest
  ): void {

    this.selectedRequest = request;

    this.showPayModal = true;

    this.payLoading = true;

    clearTimeout(this.payTimer);

    this.payTimer = setTimeout(
      () => {

        this.payLoading = false;

      },
      1500
    );
  }

  // =========================================================
  // CLOSE PAYMENT MODAL
  // =========================================================

  closePayModal(): void {

    clearTimeout(this.payTimer);

    this.showPayModal = false;

    this.payLoading = false;

    this.selectedRequest = null;
  }

  // =========================================================
  // CREATE RAZORPAY ORDER + OPEN CHECKOUT
  // =========================================================

  payNow(): void {

    const request =
      this.selectedRequest;

    if (!request) {
      return;
    }

    if (
      request.driverRequestId === undefined
    ) {

      alert(
        'Driver request ID is missing.'
      );

      return;
    }

    if (
      request.paymentAmount === undefined ||
      request.paymentAmount <= 0
    ) {

      alert(
        'Invalid payment amount.'
      );

      return;
    }

    const driverRequestId =
      request.driverRequestId;

    /*
     * Disable the button while
     * creating the Razorpay order.
     */
    this.payLoading = true;

    this.paymentService
      .createOrder(driverRequestId)
      .subscribe({

        // ===================================================
        // ORDER CREATED SUCCESSFULLY
        // ===================================================

        next: (order: any) => {

          this.payLoading = false;

          console.log(
            'Razorpay order created:',
            order
          );

          const options = {

            // Razorpay Test Key ID
            key: order.keyId,

            // Amount is in paise
            amount: order.amount,

            currency: order.currency,

            name: 'DriveU',

            description:
              'Driver Trip Payment',

            // Razorpay order created by backend
            order_id:
              order.orderId,

            // =================================================
            // PAYMENT SUCCESS CALLBACK
            // =================================================

            handler: (response: any) => {

              console.log(
                'Razorpay payment response:',
                response
              );

              /*
               * Razorpay returns:
               *
               * razorpay_order_id
               * razorpay_payment_id
               * razorpay_signature
               *
               * We send all three to Spring Boot.
               */

              const paymentData = {

                razorpay_order_id:
                  response.razorpay_order_id,

                razorpay_payment_id:
                  response.razorpay_payment_id,

                razorpay_signature:
                  response.razorpay_signature

              };

              /*
               * Send Razorpay response
               * to Spring Boot for verification.
               */

              this.paymentService
                .verifyPayment(
                  paymentData
                )
                .subscribe({

                  // ==========================================
                  // VERIFICATION SUCCESS
                  // ==========================================

                  next: (result: any) => {

                    console.log(
                      'Payment verification result:',
                      result
                    );

                    if (
                      result.success === true
                    ) {

                      alert(
                        'Payment successful!'
                      );

                      /*
                       * Update current request
                       * immediately in the UI.
                       */

                      if (
                        this.selectedRequest
                      ) {

                        this.selectedRequest.status =
                          'Closed';
                      }

                      /*
                       * Close payment modal.
                       */

                      this.closePayModal();

                      /*
                       * Reload requests from
                       * the database.
                       */

                      this.loadRequests();

                    } else {

                      alert(
                        'Payment verification failed.'
                      );
                    }

                  },

                  // ==========================================
                  // VERIFICATION ERROR
                  // ==========================================

                  error: (error) => {

                    console.error(
                      'Payment verification error:',
                      error
                    );

                    alert(
                      'Payment was completed, but server verification failed. Please contact support.'
                    );
                  }

                });

            },

            // =================================================
            // CUSTOMER INFORMATION
            // =================================================

            prefill: {

              name:
                this.authService
                  .getUsername() || ''

            },

            // =================================================
            // RAZORPAY UI
            // =================================================

            theme: {

              color: '#3399cc'

            },

            // =================================================
            // CHECKOUT CLOSED
            // =================================================

            modal: {

              ondismiss: () => {

                console.log(
                  'Razorpay checkout closed.'
                );

              }

            }

          };

          /*
           * Create Razorpay Checkout object.
           */

          const razorpay =
            new Razorpay(options);

          /*
           * Open Razorpay payment window.
           */

          razorpay.open();

        },

        // ===================================================
        // ORDER CREATION ERROR
        // ===================================================

        error: (error) => {

          this.payLoading = false;

          console.error(
            'Payment order creation failed:',
            error
          );

          alert(
            'Unable to start payment. Please try again.'
          );

        }

      });
  }

  // =========================================================
  // WRITE REVIEW
  // =========================================================

  writeReview(): void {

    const driverId =
      this.selectedRequest
        ?.driver
        ?.driverId;

    this.closePayModal();

    this.router.navigate(
      ['/customerpostfeedback'],
      {
        queryParams:
          driverId !== undefined
            ? {
              driverId
            }
            : {}
      }
    );
  }
}