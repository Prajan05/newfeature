import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from '../../apiconfig';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  private paymentUrl = `${apiUrl}/api/payment`;

  constructor(private http: HttpClient) {}

  createOrder(driverRequestId: number): Observable<any> {

    return this.http.post(
      `${this.paymentUrl}/create-order/${driverRequestId}`,
      {}
    );
  }

  verifyPayment(paymentData: {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
  }): Observable<any> {

    return this.http.post(
      `${this.paymentUrl}/verify`,
      paymentData
    );
  }
}